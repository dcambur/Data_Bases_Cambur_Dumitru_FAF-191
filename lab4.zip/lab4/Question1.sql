SELECT * FROM dbo.grupe;
GO